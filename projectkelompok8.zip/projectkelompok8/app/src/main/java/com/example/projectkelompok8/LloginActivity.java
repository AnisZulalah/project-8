package com.example.projectkelompok8;



import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LloginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_llogin);

        // Menghubungkan elemen-elemen XML ke Java
        ImageView logoImageView = findViewById(R.id.logoImageView);
        TextView welcomeTextView = findViewById(R.id.textView);
        TextView stepTextView = findViewById(R.id.textView);
        TextView haveAccountTextView = findViewById(R.id.textView);
        Button loginButton = findViewById(R.id.loginButton);

        // Listener untuk tombol LOGIN
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigasi ke halaman lain
                Intent intent = new Intent(LloginActivity.this, registerActivity.class);
                startActivity(intent);
            }
        });

        // Listener untuk teks "Already Have your an Account"
        haveAccountTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(LloginActivity.this, "Already have an account clicked", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
